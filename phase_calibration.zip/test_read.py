from read import read_all, save_all_tables
read_all() # read 2048 個 complex response table
save_all_tables()